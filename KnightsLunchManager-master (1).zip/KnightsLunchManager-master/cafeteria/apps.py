from django.apps import AppConfig


class CafeteriaConfig(AppConfig):
    name = 'cafeteria'
    verbose_name = 'Cafeteria Administration'
