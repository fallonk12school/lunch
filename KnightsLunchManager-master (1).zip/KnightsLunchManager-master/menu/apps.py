from django.apps import AppConfig


class MenuConfig(AppConfig):
    name = 'menu'
    verbose_name = 'Menu Management'
